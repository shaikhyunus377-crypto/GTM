"""
Generates the sample Excel deliverable shown to clients.
Simulates exactly what they receive after pipeline runs.
"""

import openpyxl
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, CellIsRule, FormulaRule
from openpyxl.worksheet.datavalidation import DataValidation
import os

# ── Colour palette ────────────────────────────────────────────────────────────
DARK_NAVY   = "0D1B2A"
MID_BLUE    = "1B4F72"
ACCENT_TEAL = "148F77"
LIGHT_TEAL  = "D1F2EB"
ACCENT_AMB  = "D4AC0D"
LIGHT_AMB   = "FEF9E7"
RED_ALERT   = "E74C3C"
LIGHT_RED   = "FDEDEC"
GREEN_OK    = "27AE60"
LIGHT_GREEN = "EAFAF1"
WHITE       = "FFFFFF"
LIGHT_GRAY  = "F4F6F7"
MID_GRAY    = "BDC3C7"
DARK_GRAY   = "566573"
HEADER_BG   = "1A252F"

def thin_border():
    s = Side(style="thin", color=MID_GRAY)
    return Border(left=s, right=s, top=s, bottom=s)

def header_border():
    s = Side(style="medium", color=DARK_NAVY)
    return Border(left=s, right=s, top=s, bottom=s)

# ── Sample lead data ──────────────────────────────────────────────────────────
LEADS = [
    {
        "no": 1,
        "business_name": "WeCare Family Dentistry",
        "owner_name": "Dr. Esther Aniemeke",
        "owner_email": "info@wecarefamdental.com",
        "email_confidence": "High",
        "email_source": "Website (scraped)",
        "phone": "(210) 898-8601",
        "address": "7228 Bandera Rd #104, San Antonio TX 78238",
        "website": "wecarefamdental.com",
        "google_rating": 4.5,
        "review_count": 102,
        "site_tech": "WordPress + Divi",
        "domain_age_yrs": 6.2,
        "mobile_score": 41,
        "site_era": "Outdated",
        "has_own_form": "YES — Own Form",
        "form_platform": "Gravity Forms (WordPress)",
        "cro_issues_count": 4,
        "top_cro_issue": "No confirmation message after form submit — patient doesn't know if booking went through",
        "all_cro_issues": "No confirmation message | Generic 'Submit' button text | No trust signals near form | No date/time picker",
        "severity": "HIGH",
        "conv_loss_est": "25–35%",
        "ai_email_opener": "Dr. Aniemeke, patients submit your booking form and get no confirmation — most assume it failed and call someone else.",
        "status": "Not Contacted",
    },
    {
        "no": 2,
        "business_name": "Hildebrand Family Dental Care",
        "owner_name": "Dr. Evgenia Seryogina",
        "owner_email": "info@hildebrandfamilydental.com",
        "email_confidence": "High",
        "email_source": "Hunter.io Domain Search",
        "phone": "(210) 733-9477",
        "address": "1001 W Hildebrand Ave, San Antonio TX 78201",
        "website": "hildebrandfamilydental.com",
        "google_rating": 4.9,
        "review_count": 304,
        "site_tech": "WordPress",
        "domain_age_yrs": 9.1,
        "mobile_score": 38,
        "site_era": "Outdated",
        "has_own_form": "YES — Own Form",
        "form_platform": "Contact Form 7 (WordPress)",
        "cro_issues_count": 3,
        "top_cro_issue": "$79 new patient special advertised on every page — completely disappears on the appointment form",
        "all_cro_issues": "Offer disappears at form | EN/ES mismatch (Spanish toggle, English-only form) | JS-only form breaks on slow mobile",
        "severity": "HIGH",
        "conv_loss_est": "20–30%",
        "ai_email_opener": "Dr. Seryogina, your $79 new patient offer is on every page — but vanishes the moment someone clicks 'Request Appointment.'",
        "status": "Not Contacted",
    },
    {
        "no": 3,
        "business_name": "Alamo City Dental Group",
        "owner_name": "Dr. Marcus Reyes",
        "owner_email": "dreyes@alamocitydental.com",
        "email_confidence": "Medium",
        "email_source": "Hunter.io Email Finder",
        "phone": "(210) 224-5500",
        "address": "902 W Basse Rd #150, San Antonio TX 78212",
        "website": "alamocitydental.com",
        "google_rating": 4.2,
        "review_count": 87,
        "site_tech": "Squarespace",
        "domain_age_yrs": 4.7,
        "mobile_score": 55,
        "site_era": "Mixed",
        "has_own_form": "YES — Own Form",
        "form_platform": "Squarespace Native Form",
        "cro_issues_count": 2,
        "top_cro_issue": "Form asks 7 fields upfront including insurance details — high abandonment before submission",
        "all_cro_issues": "Too many required fields (7) | No response time promise near submit button",
        "severity": "MEDIUM",
        "conv_loss_est": "15–25%",
        "ai_email_opener": "Dr. Reyes, your booking form asks for insurance info before patients even know if you accept them — that's where most drop off.",
        "status": "Not Contacted",
    },
    {
        "no": 4,
        "business_name": "Southside Smiles Dental",
        "owner_name": "Dr. Patricia Lozano",
        "owner_email": "plozano@southsidesmiles.com",
        "email_confidence": "High",
        "email_source": "Website (mailto link)",
        "phone": "(210) 532-8900",
        "address": "3310 SE Military Dr #108, San Antonio TX 78223",
        "website": "southsidesmiles.com",
        "google_rating": 4.1,
        "review_count": 63,
        "site_tech": "WordPress + Elementor",
        "domain_age_yrs": 7.8,
        "mobile_score": 28,
        "site_era": "Outdated",
        "has_own_form": "YES — Own Form",
        "form_platform": "WPForms (WordPress)",
        "cro_issues_count": 4,
        "top_cro_issue": "Mobile score 28/100 — site is nearly unusable on phone, and 73% of dental searches happen on mobile",
        "all_cro_issues": "Mobile score 28/100 (broken) | No confirmation UX | Submit button invisible on small screens | No trust signals",
        "severity": "HIGH",
        "conv_loss_est": "30–40%",
        "ai_email_opener": "Dr. Lozano, your site scores 28/100 on mobile speed — most patients searching for a dentist on their phone can't load your booking form.",
        "status": "Not Contacted",
    },
    {
        "no": 5,
        "business_name": "Heritage Oaks Family Dentistry",
        "owner_name": "Dr. James Whitfield",
        "owner_email": "james@heritageoaksdental.com",
        "email_confidence": "High",
        "email_source": "About page (scraped)",
        "phone": "(210) 695-4400",
        "address": "11230 Bandera Rd #109, San Antonio TX 78250",
        "website": "heritageoaksdental.com",
        "google_rating": 4.3,
        "review_count": 211,
        "site_tech": "WordPress",
        "domain_age_yrs": 11.3,
        "mobile_score": 46,
        "site_era": "Outdated",
        "has_own_form": "YES — Own Form",
        "form_platform": "Contact Form 7 (WordPress)",
        "cro_issues_count": 3,
        "top_cro_issue": "84 Google reviews with 0% reply rate — trust gap visible to every potential patient before they even reach the site",
        "all_cro_issues": "0% review reply rate (84 reviews) | No trust signals on form | Generic button text ('Send Message')",
        "severity": "MEDIUM",
        "conv_loss_est": "15–20%",
        "ai_email_opener": "Dr. Whitfield, you have 84 Google reviews and haven't replied to a single one — that's the first thing new patients see before visiting your site.",
        "status": "Not Contacted",
    },
]

COLS = [
    ("#",              4),
    ("Business Name",  28),
    ("Owner Name",     22),
    ("Owner Email",    30),
    ("Email Confidence", 14),
    ("Email Source",   20),
    ("Phone",          16),
    ("Address",        36),
    ("Website",        26),
    ("Google Rating",  13),
    ("Reviews",        10),
    ("Site Tech",      20),
    ("Domain Age (yrs)", 14),
    ("Mobile Score /100", 15),
    ("Site Era",       12),
    ("Own Form?",      22),
    ("Form Platform",  24),
    ("CRO Issues #",   12),
    ("Top CRO Issue",  50),
    ("All CRO Issues", 60),
    ("Severity",       12),
    ("Est. Conv. Loss", 15),
    ("AI Email Opener", 60),
    ("Status",         16),
]

FIELD_KEYS = [
    "no", "business_name", "owner_name", "owner_email",
    "email_confidence", "email_source", "phone", "address", "website",
    "google_rating", "review_count", "site_tech", "domain_age_yrs",
    "mobile_score", "site_era", "has_own_form", "form_platform",
    "cro_issues_count", "top_cro_issue", "all_cro_issues",
    "severity", "conv_loss_est", "ai_email_opener", "status",
]


def make_excel(path):
    wb = openpyxl.Workbook()

    # ── Sheet 1: Qualified Leads ──────────────────────────────────────────────
    ws = wb.active
    ws.title = "Qualified Leads"
    ws.freeze_panes = "B3"
    ws.sheet_view.showGridLines = False

    # ── Title row ─────────────────────────────────────────────────────────────
    ws.row_dimensions[1].height = 36
    ws.merge_cells("A1:X1")
    tc = ws["A1"]
    tc.value          = "🦷  LEAD QUALIFICATION REPORT  ·  Dental Clinics  ·  San Antonio, TX  ·  Batch #1"
    tc.font           = Font(name="Arial", bold=True, size=13, color=WHITE)
    tc.fill           = PatternFill("solid", fgColor=DARK_NAVY)
    tc.alignment      = Alignment(horizontal="center", vertical="center")

    # ── Sub-title / meta row ──────────────────────────────────────────────────
    ws.row_dimensions[2].height = 20
    ws.merge_cells("A2:X2")
    mc = ws["A2"]
    mc.value     = "Pipeline: Google Maps scrape → Website check → Own-form gate → CRO analysis → Owner email → AI opener   |   5 qualified leads from 47 scraped"
    mc.font      = Font(name="Arial", size=9, color="AAAAAA", italic=True)
    mc.fill      = PatternFill("solid", fgColor="1A252F")
    mc.alignment = Alignment(horizontal="center", vertical="center")

    # ── Column headers (row 3) ────────────────────────────────────────────────
    ws.row_dimensions[3].height = 30
    for col_idx, (label, width) in enumerate(COLS, start=1):
        col_letter = get_column_letter(col_idx)
        ws.column_dimensions[col_letter].width = width
        cell = ws.cell(row=3, column=col_idx, value=label)
        cell.font      = Font(name="Arial", bold=True, size=9, color=WHITE)
        cell.fill      = PatternFill("solid", fgColor=MID_BLUE)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border    = header_border()

    # ── Data rows ─────────────────────────────────────────────────────────────
    for row_idx, lead in enumerate(LEADS, start=4):
        ws.row_dimensions[row_idx].height = 80
        bg = LIGHT_GRAY if row_idx % 2 == 0 else WHITE

        for col_idx, key in enumerate(FIELD_KEYS, start=1):
            cell        = ws.cell(row=row_idx, column=col_idx, value=lead[key])
            cell.border = thin_border()
            cell.font   = Font(name="Arial", size=9)
            cell.fill   = PatternFill("solid", fgColor=bg)
            cell.alignment = Alignment(
                vertical="center", wrap_text=True,
                horizontal="center" if col_idx in [1, 10, 11, 13, 14, 18, 21, 22] else "left"
            )

            # ── special cell colouring ────────────────────────────────────
            # Severity
            if key == "severity":
                if lead[key] == "HIGH":
                    cell.fill = PatternFill("solid", fgColor=LIGHT_RED)
                    cell.font = Font(name="Arial", size=9, bold=True, color=RED_ALERT)
                elif lead[key] == "MEDIUM":
                    cell.fill = PatternFill("solid", fgColor=LIGHT_AMB)
                    cell.font = Font(name="Arial", size=9, bold=True, color="B7950B")

            # Mobile score colour
            if key == "mobile_score":
                score = lead[key]
                if score < 40:
                    cell.fill = PatternFill("solid", fgColor=LIGHT_RED)
                    cell.font = Font(name="Arial", size=9, bold=True, color=RED_ALERT)
                elif score < 60:
                    cell.fill = PatternFill("solid", fgColor=LIGHT_AMB)
                    cell.font = Font(name="Arial", size=9, color="B7950B", bold=True)
                else:
                    cell.fill = PatternFill("solid", fgColor=LIGHT_GREEN)
                    cell.font = Font(name="Arial", size=9, color=GREEN_OK, bold=True)

            # Email confidence
            if key == "email_confidence":
                if lead[key] == "High":
                    cell.font = Font(name="Arial", size=9, color=GREEN_OK, bold=True)
                else:
                    cell.font = Font(name="Arial", size=9, color=ACCENT_AMB, bold=True)

            # Own form highlight
            if key == "has_own_form":
                cell.fill = PatternFill("solid", fgColor=LIGHT_TEAL)
                cell.font = Font(name="Arial", size=9, bold=True, color=ACCENT_TEAL)

            # AI opener highlight
            if key == "ai_email_opener":
                cell.fill = PatternFill("solid", fgColor="EBF5FB")
                cell.font = Font(name="Arial", size=9, italic=True, color=MID_BLUE)

            # Website as hyperlink
            if key == "website":
                cell.hyperlink  = f"https://{lead[key]}"
                cell.font       = Font(name="Arial", size=9, color=MID_BLUE, underline="single")

            # Status dropdown colour
            if key == "status":
                cell.fill = PatternFill("solid", fgColor=LIGHT_GRAY)
                cell.font = Font(name="Arial", size=9, bold=True, color=DARK_GRAY)

    # ── Status dropdown validation ────────────────────────────────────────────
    dv = DataValidation(
        type="list",
        formula1='"Not Contacted,Emailed,Replied — Interested,Replied — Not Interested,Deal Closed,Follow Up"',
        allow_blank=True
    )
    ws.add_data_validation(dv)
    dv.sqref = f"X4:X{3 + len(LEADS)}"

    # ── Summary row ───────────────────────────────────────────────────────────
    sum_row = 4 + len(LEADS)
    ws.row_dimensions[sum_row].height = 22
    ws.merge_cells(f"A{sum_row}:I{sum_row}")
    sc = ws[f"A{sum_row}"]
    sc.value     = f"Total qualified leads: {len(LEADS)}   |   High severity: {sum(1 for l in LEADS if l['severity']=='HIGH')}   |   Avg mobile score: {round(sum(l['mobile_score'] for l in LEADS)/len(LEADS))}/100"
    sc.font      = Font(name="Arial", bold=True, size=9, color=WHITE)
    sc.fill      = PatternFill("solid", fgColor=MID_BLUE)
    sc.alignment = Alignment(horizontal="left", vertical="center")
    sc.border    = header_border()
    for col_idx in range(2, len(COLS) + 1):
        ec = ws.cell(row=sum_row, column=col_idx)
        ec.fill   = PatternFill("solid", fgColor=MID_BLUE)
        ec.border = header_border()

    # ── Sheet 2: How To Use ───────────────────────────────────────────────────
    ws2 = wb.create_sheet("How To Use This File")
    ws2.sheet_view.showGridLines = False
    ws2.column_dimensions["A"].width = 4
    ws2.column_dimensions["B"].width = 24
    ws2.column_dimensions["C"].width = 70

    def s2(row, col, val, bold=False, size=10, color=DARK_NAVY, bg=None, height=None):
        cell = ws2.cell(row=row, column=col, value=val)
        cell.font = Font(name="Arial", bold=bold, size=size, color=color)
        cell.alignment = Alignment(vertical="center", wrap_text=True, indent=1)
        if bg:
            cell.fill = PatternFill("solid", fgColor=bg)
        if height:
            ws2.row_dimensions[row].height = height
        return cell

    ws2.merge_cells("A1:C1")
    h = ws2["A1"]
    h.value     = "📋  HOW TO USE YOUR LEAD REPORT"
    h.font      = Font(name="Arial", bold=True, size=14, color=WHITE)
    h.fill      = PatternFill("solid", fgColor=DARK_NAVY)
    h.alignment = Alignment(horizontal="center", vertical="center")
    ws2.row_dimensions[1].height = 40

    sections = [
        (3,  "STEP 1", "Open 'Qualified Leads' tab — every lead here has passed all 5 qualification gates."),
        (5,  "STEP 2", "Look at 'Top CRO Issue' column (column S) — this is the specific problem we found on their website."),
        (7,  "STEP 3", "Copy the 'AI Email Opener' (column W) — paste it as the first sentence of your cold email."),
        (9,  "STEP 4", "Personalise the rest of your email around the issue found. Send from your warmed-up domain."),
        (11, "STEP 5", "After sending, update the 'Status' column (column X) — use the dropdown to track each lead."),
        (13, "STEP 6", "Screenshot the mobile score or CRO issue and attach it to your email as visual proof."),
    ]

    for row, label, desc in sections:
        ws2.row_dimensions[row].height = 40
        s2(row, 2, label, bold=True, size=10, color=WHITE, bg=MID_BLUE)
        s2(row, 3, desc,  bold=False, size=10, color=DARK_NAVY)

    ws2.merge_cells("B15:C15")
    n = ws2["B15"]
    n.value     = "⚠️  Column colour guide: RED = high severity issue  |  AMBER = medium  |  TEAL = own form confirmed  |  BLUE italic = AI-written opener"
    n.font      = Font(name="Arial", size=9, italic=True, color="7D6608")
    n.fill      = PatternFill("solid", fgColor=LIGHT_AMB)
    n.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True, indent=1)
    ws2.row_dimensions[15].height = 30

    # ── Sheet 3: Pipeline Summary ─────────────────────────────────────────────
    ws3 = wb.create_sheet("Pipeline Summary")
    ws3.sheet_view.showGridLines = False
    ws3.column_dimensions["A"].width = 4
    ws3.column_dimensions["B"].width = 32
    ws3.column_dimensions["C"].width = 20

    ws3.merge_cells("A1:C1")
    ph = ws3["A1"]
    ph.value     = "⚙️  PIPELINE RUN SUMMARY"
    ph.font      = Font(name="Arial", bold=True, size=13, color=WHITE)
    ph.fill      = PatternFill("solid", fgColor=DARK_NAVY)
    ph.alignment = Alignment(horizontal="center", vertical="center")
    ws3.row_dimensions[1].height = 36

    summary_rows = [
        ("Run date",               "2025-05-02"),
        ("Niche",                  "Dental Clinic"),
        ("City / State",           "San Antonio, TX"),
        ("Total scraped from Maps", "47"),
        ("Passed: has website",    "39"),
        ("Passed: has own form",   "21"),
        ("Passed: CRO issues found","14"),
        ("Passed: rating 3.5–4.5", "9"),
        ("Passed: owner email found","5"),
        ("FINAL QUALIFIED LEADS",  "5"),
        ("Conversion rate",         "10.6%"),
        ("Avg mobile score",        "41 / 100"),
        ("High severity leads",     "3 of 5"),
    ]

    for i, (label, val) in enumerate(summary_rows, start=3):
        ws3.row_dimensions[i].height = 22
        lc = ws3.cell(row=i, column=2, value=label)
        vc = ws3.cell(row=i, column=3, value=val)
        is_total = label == "FINAL QUALIFIED LEADS"
        bg = LIGHT_TEAL if is_total else (LIGHT_GRAY if i % 2 == 0 else WHITE)
        lc.fill = PatternFill("solid", fgColor=bg)
        vc.fill = PatternFill("solid", fgColor=bg)
        lc.font = Font(name="Arial", size=10, bold=is_total, color=ACCENT_TEAL if is_total else DARK_NAVY)
        vc.font = Font(name="Arial", size=10, bold=is_total, color=ACCENT_TEAL if is_total else DARK_NAVY)
        lc.alignment = Alignment(vertical="center", indent=1)
        vc.alignment = Alignment(vertical="center", horizontal="center")
        lc.border = thin_border()
        vc.border = thin_border()

    wb.save(path)
    print(f"Saved: {path}")


if __name__ == "__main__":
    os.makedirs("/mnt/user-data/outputs", exist_ok=True)
    make_excel("/mnt/user-data/outputs/LeadReport_DentalClinics_SanAntonio_Batch1.xlsx")
