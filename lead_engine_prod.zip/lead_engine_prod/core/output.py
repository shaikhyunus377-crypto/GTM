"""
core/output.py
Saves qualified leads to Excel (.xlsx) and/or CSV.
Excel file uses the same professional formatting as the client sample.
"""

import csv
import os
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


DARK_NAVY = "0D1B2A"
MID_BLUE  = "1B4F72"
TEAL      = "148F77"
LIGHT_RED = "FDEDEC"
LIGHT_AMB = "FEF9E7"
LIGHT_GRN = "EAFAF1"
WHITE     = "FFFFFF"
LIGHT_GRY = "F4F6F7"
MID_GRAY  = "BDC3C7"
RED       = "E74C3C"
GREEN     = "27AE60"
AMB       = "D4AC0D"

COLUMNS = [
    ("#",               "no",               5),
    ("Business Name",   "business_name",    28),
    ("Owner Name",      "owner_name",       22),
    ("Owner Email",     "owner_email",      30),
    ("Email Source",    "email_source",     18),
    ("Phone",           "phone",            16),
    ("Website",         "website",          26),
    ("Rating",          "google_rating",    10),
    ("Reviews",         "review_count",     10),
    ("Site Tech",       "site_tech",        18),
    ("Domain Age",      "domain_age_yrs",   12),
    ("Mobile Score",    "mobile_score",     13),
    ("Site Era",        "site_era",         12),
    ("Own Form?",       "has_own_form",     10),
    ("Form Platform",   "form_platform",    22),
    ("CRO Issues #",    "cro_issues_count", 12),
    ("Top CRO Issue",   "top_cro_issue",    50),
    ("Severity",        "severity",         12),
    ("Conv. Loss Est.", "conv_loss_est",     14),
    ("AI Email Opener", "ai_email_opener",   60),
    ("Status",          "status",            16),
]


def thin():
    s = Side(style="thin", color=MID_GRAY)
    return Border(left=s, right=s, top=s, bottom=s)


def save_to_excel(leads: list, path: str, config: dict):
    wb = Workbook()
    ws = wb.active
    ws.title = "Qualified Leads"
    ws.freeze_panes = "B3"
    ws.sheet_view.showGridLines = False

    # Title
    ws.merge_cells(f"A1:{get_column_letter(len(COLUMNS))}1")
    title_cell = ws["A1"]
    title_cell.value = (
        f"Lead Report — {config.get('niche','').title()} — "
        f"{config.get('city','')} — "
        f"{datetime.now().strftime('%Y-%m-%d')}"
    )
    title_cell.font      = Font(name="Arial", bold=True, size=12, color=WHITE)
    title_cell.fill      = PatternFill("solid", fgColor=DARK_NAVY)
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    # Sub-header
    ws.merge_cells(f"A2:{get_column_letter(len(COLUMNS))}2")
    sub = ws["A2"]
    sub.value = (
        f"{len(leads)} qualified leads | "
        f"Pipeline: Maps scrape → website check → form gate → CRO analysis → owner email → AI opener"
    )
    sub.font      = Font(name="Arial", size=9, color="AAAAAA", italic=True)
    sub.fill      = PatternFill("solid", fgColor="1A252F")
    sub.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 18

    # Column headers
    ws.row_dimensions[3].height = 28
    for col_idx, (label, _, width) in enumerate(COLUMNS, start=1):
        letter = get_column_letter(col_idx)
        ws.column_dimensions[letter].width = width
        c = ws.cell(row=3, column=col_idx, value=label)
        c.font      = Font(name="Arial", bold=True, size=9, color=WHITE)
        c.fill      = PatternFill("solid", fgColor=MID_BLUE)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = thin()

    # Data rows
    for row_idx, lead in enumerate(leads, start=4):
        ws.row_dimensions[row_idx].height = 72
        bg = LIGHT_GRY if row_idx % 2 == 0 else WHITE

        for col_idx, (_, key, _) in enumerate(COLUMNS, start=1):
            val  = lead.get(key, "")
            if key == "no":
                val = row_idx - 3

            c = ws.cell(row=row_idx, column=col_idx, value=val)
            c.border    = thin()
            c.font      = Font(name="Arial", size=9)
            c.fill      = PatternFill("solid", fgColor=bg)
            c.alignment = Alignment(vertical="center", wrap_text=True,
                                    horizontal="center" if key in
                                    ["no","google_rating","review_count",
                                     "domain_age_yrs","mobile_score","cro_issues_count"]
                                    else "left")

            # Colour overrides
            if key == "severity":
                if str(val) == "HIGH":
                    c.fill = PatternFill("solid", fgColor=LIGHT_RED)
                    c.font = Font(name="Arial", size=9, bold=True, color=RED)
                elif str(val) == "MEDIUM":
                    c.fill = PatternFill("solid", fgColor=LIGHT_AMB)
                    c.font = Font(name="Arial", size=9, bold=True, color="B7950B")

            if key == "mobile_score" and val is not None:
                try:
                    score = int(val)
                    if score < 40:
                        c.fill = PatternFill("solid", fgColor=LIGHT_RED)
                        c.font = Font(name="Arial", size=9, bold=True, color=RED)
                    elif score < 60:
                        c.fill = PatternFill("solid", fgColor=LIGHT_AMB)
                        c.font = Font(name="Arial", size=9, bold=True, color="B7950B")
                    else:
                        c.fill = PatternFill("solid", fgColor=LIGHT_GRN)
                        c.font = Font(name="Arial", size=9, bold=True, color=GREEN)
                except (ValueError, TypeError):
                    pass

            if key == "has_own_form":
                c.fill = PatternFill("solid", fgColor="D1F2EB")
                c.font = Font(name="Arial", size=9, bold=True, color=TEAL)

            if key == "ai_email_opener":
                c.fill = PatternFill("solid", fgColor="EBF5FB")
                c.font = Font(name="Arial", size=9, italic=True, color=MID_BLUE)

            if key == "website" and val:
                c.hyperlink = f"https://{val}" if not str(val).startswith("http") else val
                c.font      = Font(name="Arial", size=9, color=MID_BLUE, underline="single")

            if key == "status":
                c.value = "Not Contacted"
                c.font  = Font(name="Arial", size=9, color="566573")

    wb.save(path)


def save_to_csv(leads: list, path: str):
    if not leads:
        return
    fieldnames = [key for _, key, _ in COLUMNS]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for i, lead in enumerate(leads, start=1):
            row = {key: lead.get(key, "") for _, key, _ in COLUMNS}
            row["no"] = i
            row["status"] = "Not Contacted"
            writer.writerow(row)
