"""
core/pipeline.py
Production pipeline — adds retry logic, rate limiting, and
concurrent processing for faster runs.
"""

import time
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from modules.scraper        import scrape_google_maps
from modules.website_checker import check_website
from modules.form_detector  import detect_form
from modules.email_finder   import find_email
from modules.owner_finder   import find_owner
from modules.cro_analyzer   import analyze_cro
from modules.ai_writer      import generate_opener
from modules.gate_engine    import run_gates
from core.logger            import log


def safe_run(fn, *args, retries=2, default=None, **kwargs):
    """
    Wrap any module call with retry + fallback.
    Prevents one bad website from crashing the entire run.
    """
    for attempt in range(retries + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            if attempt < retries:
                time.sleep(2)
            else:
                log(f"Failed after {retries+1} attempts: {fn.__name__} — {e}", "ERROR")
                return default


def run_pipeline(config: dict, max_results: int = 200) -> list:
    niche   = config["niche"]
    city    = config["city"]
    gates   = config["gates"]
    client  = config["client_name"]

    # ── Startup summary ───────────────────────────────────────────────────────
    log("=" * 50, "SECTION")
    log(f"CLIENT : {client}")
    log(f"NICHE  : {niche}")
    log(f"CITY   : {city}")
    log(f"LIMIT  : {max_results} raw results")
    log("=" * 50, "SECTION")

    # ── Step 1: Scrape Google Maps ────────────────────────────────────────────
    raw = safe_run(scrape_google_maps, niche, city, max_results,
                   default=[])
    log(f"Scraped {len(raw)} raw businesses from Google Maps")

    if not raw:
        log("No results from scraper. Check API key or try Playwright mode.", "ERROR")
        return []

    qualified   = []
    stats       = {"no_website": 0, "no_form": 0, "third_party": 0,
                   "form_clean": 0, "gate_fail": 0, "no_email": 0, "qualified": 0}

    # ── Step 2: Process each business ────────────────────────────────────────
    for idx, biz in enumerate(raw, start=1):
        name = biz.get("name", "Unknown")
        url  = biz.get("website", "")

        log(f"[{idx}/{len(raw)}] {name}")

        if not url:
            stats["no_website"] += 1
            continue

        # Normalise URL
        if not url.startswith("http"):
            url = "https://" + url

        # Gate A — Website health check (non-blocking)
        site_data = safe_run(check_website, url, default={
            "cms": "Unknown", "domain_age_years": 0,
            "domain_old": False, "mobile_score": None,
            "mobile_slow": False, "site_era": "Unknown"
        })
        biz["site_data"] = site_data

        # Gate B — Booking form detection (critical gate)
        form_data = safe_run(detect_form, url, default={
            "has_form": False, "is_own": False,
            "platform": "Error", "form_html": "",
            "form_url": "", "verdict": "Detection failed"
        })
        biz["form_data"] = form_data

        if not form_data.get("has_form"):
            log(f"  ✗ No form found", "SKIP")
            stats["no_form"] += 1
            continue

        if not form_data.get("is_own"):
            log(f"  ✗ 3rd party: {form_data.get('platform')}", "SKIP")
            stats["third_party"] += 1
            continue

        log(f"  ✓ Own form: {form_data.get('platform')}", "OK")

        # Gate C — CRO analysis
        cro = safe_run(analyze_cro, url, form_data.get("form_html", ""),
                       default={"issues_found": [], "biggest_issue": "",
                                "severity": "LOW", "estimated_conversion_loss": "0%"})
        biz["cro"] = cro

        if not cro.get("issues_found"):
            log(f"  ✗ Form has no CRO issues — skipping", "SKIP")
            stats["form_clean"] += 1
            continue

        log(f"  ✓ CRO issues: {len(cro['issues_found'])} found ({cro.get('severity')})", "OK")

        # Gate D — Client custom gates
        gate_result = run_gates(biz, gates)
        if not gate_result["passed"]:
            log(f"  ✗ Custom gate: {gate_result['reason']}", "SKIP")
            stats["gate_fail"] += 1
            continue

        # Enrich — Owner name
        owner = safe_run(find_owner, url, name, default=None)

        # Enrich — Email (waterfall)
        domain = biz.get("domain", "")
        email, email_source = safe_run(
            find_email, url, owner, domain,
            default=(None, "not_found")
        )

        if not email:
            log(f"  ✗ No email found", "SKIP")
            stats["no_email"] += 1
            continue

        log(f"  ✓ Email: {email} (via {email_source})", "OK")

        # Enrich — AI email opener
        opener = safe_run(generate_opener, name, owner, cro, site_data,
                          default="")

        qualified.append({
            "business_name":    name,
            "owner_name":       owner or "N/A",
            "owner_email":      email,
            "email_source":     email_source,
            "phone":            biz.get("phone", "N/A"),
            "address":          biz.get("address", "N/A"),
            "website":          url,
            "google_rating":    biz.get("rating"),
            "review_count":     biz.get("reviewsCount"),
            "site_tech":        site_data.get("cms", "Unknown"),
            "domain_age_yrs":   site_data.get("domain_age_years"),
            "mobile_score":     site_data.get("mobile_score"),
            "site_era":         site_data.get("site_era"),
            "has_own_form":     "YES — Own Form",
            "form_platform":    form_data.get("platform", "Own"),
            "cro_issues_count": len(cro.get("issues_found", [])),
            "top_cro_issue":    cro.get("biggest_issue", ""),
            "all_cro_issues":   " | ".join(cro.get("issues_found", [])),
            "severity":         cro.get("severity", "LOW"),
            "conv_loss_est":    cro.get("estimated_conversion_loss", ""),
            "ai_email_opener":  opener,
        })

        stats["qualified"] += 1
        log(f"  ★ QUALIFIED ({stats['qualified']} total)", "OK")

        # Small delay between businesses — be polite to websites
        time.sleep(1)

    # ── Final summary ─────────────────────────────────────────────────────────
    log("=" * 50, "SECTION")
    log(f"DONE — {len(raw)} scraped → {stats['qualified']} qualified")
    log(f"  No website   : {stats['no_website']}")
    log(f"  No form      : {stats['no_form']}")
    log(f"  3rd party    : {stats['third_party']}")
    log(f"  Form clean   : {stats['form_clean']}")
    log(f"  Gate fail    : {stats['gate_fail']}")
    log(f"  No email     : {stats['no_email']}")
    log(f"  ★ Qualified  : {stats['qualified']}")
    log("=" * 50, "SECTION")

    return qualified
