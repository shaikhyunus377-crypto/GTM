"""
core/logger.py
Production logger — writes to console AND logs/run_YYYY-MM-DD.log
"""

import os
import sys
from datetime import datetime

LOG_DIR = os.getenv("LOG_DIR", "logs")
os.makedirs(LOG_DIR, exist_ok=True)

_log_file = os.path.join(LOG_DIR, f"run_{datetime.now().strftime('%Y-%m-%d')}.log")

ICONS = {
    "INFO":    "  ",
    "OK":      "✓ ",
    "SKIP":    "✗ ",
    "ERROR":   "⚠ ",
    "SECTION": "──",
}

def log(message: str, level: str = "INFO"):
    timestamp = datetime.now().strftime("%H:%M:%S")
    icon      = ICONS.get(level, "  ")
    line      = f"[{timestamp}] {icon} {message}"
    print(line, flush=True)
    try:
        with open(_log_file, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
