"""
Lead Qualification Engine — Production Entry Point

Usage examples:
  python main.py --client sample_dental
  python main.py --client sample_dental --limit 50 --output both
  python main.py --client sample_dental --dry-run
  python main.py --list-clients
"""

import argparse
import json
import os
import sys
from datetime import datetime

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(__file__))

from config.settings import validate_keys, OUTPUT_DIR
from core.logger     import log


def load_client_config(client_name: str) -> dict:
    path = os.path.join("clients", client_name, "config.json")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"No config found for '{client_name}'.\n"
            f"Expected: {path}\n"
            f"Run: python main.py --list-clients  to see available clients."
        )
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def list_clients():
    clients_dir = "clients"
    if not os.path.exists(clients_dir):
        print("No clients directory found.")
        return
    clients = [d for d in os.listdir(clients_dir)
               if os.path.isdir(os.path.join(clients_dir, d))
               and os.path.exists(os.path.join(clients_dir, d, "config.json"))]
    if not clients:
        print("No client configs found. Create clients/<name>/config.json")
        return
    print("\nAvailable clients:")
    for c in sorted(clients):
        cfg = json.load(open(os.path.join(clients_dir, c, "config.json")))
        print(f"  {c:<30} {cfg.get('niche','')} in {cfg.get('city','')}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Lead Qualification Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --client sample_dental
  python main.py --client sample_dental --limit 50
  python main.py --client sample_dental --output both
  python main.py --client sample_dental --dry-run
  python main.py --list-clients
        """
    )
    parser.add_argument("--client",       help="Client folder name in /clients")
    parser.add_argument("--limit",        type=int, default=200,
                        help="Max businesses to scrape (default: 200)")
    parser.add_argument("--output",       default="excel",
                        choices=["excel", "csv", "both"],
                        help="Output format (default: excel)")
    parser.add_argument("--dry-run",      action="store_true",
                        help="Validate config and API keys without running")
    parser.add_argument("--list-clients", action="store_true",
                        help="List all available client configs")
    args = parser.parse_args()

    # ── List clients ──────────────────────────────────────────────────────────
    if args.list_clients:
        list_clients()
        return

    if not args.client:
        parser.print_help()
        print("\nError: --client is required. Use --list-clients to see options.")
        sys.exit(1)

    # ── Validate API keys ─────────────────────────────────────────────────────
    keys = validate_keys()
    log("API Key Status:")
    for key, status in keys.items():
        icon = "✓" if status else "✗"
        note = "" if status else " ← NOT SET (check .env file)"
        log(f"  {icon} {key}{note}")

    if not keys["OPENAI_API_KEY"]:
        log("OPENAI_API_KEY is required for CRO analysis + AI openers.", "ERROR")
        log("Add it to your .env file. See .env.example for instructions.", "ERROR")
        if not args.dry_run:
            sys.exit(1)

    # ── Load config ───────────────────────────────────────────────────────────
    try:
        config = load_client_config(args.client)
        log(f"Config loaded: {args.client}")
        log(f"  Niche: {config['niche']} in {config['city']}")
        log(f"  Gates: {len(config['gates'])} active")
    except FileNotFoundError as e:
        log(str(e), "ERROR")
        sys.exit(1)

    if args.dry_run:
        log("Dry run complete — config and keys validated. Ready to run.")
        return

    # ── Run pipeline ──────────────────────────────────────────────────────────
    from core.pipeline import run_pipeline
    from core.output   import save_to_excel, save_to_csv

    leads = run_pipeline(config, max_results=args.limit)

    if not leads:
        log("No qualified leads found. Try a different city or increase --limit.", "ERROR")
        return

    # ── Save output ───────────────────────────────────────────────────────────
    timestamp    = datetime.now().strftime("%Y-%m-%d_%H-%M")
    client_dir   = os.path.join(OUTPUT_DIR, args.client)
    os.makedirs(client_dir, exist_ok=True)
    output_base  = os.path.join(client_dir, f"leads_{timestamp}")

    if args.output in ["excel", "both"]:
        excel_path = output_base + ".xlsx"
        save_to_excel(leads, excel_path, config)
        log(f"Excel saved → {excel_path}", "OK")

    if args.output in ["csv", "both"]:
        csv_path = output_base + ".csv"
        save_to_csv(leads, csv_path)
        log(f"CSV saved   → {csv_path}", "OK")

    log(f"Done. {len(leads)} qualified leads saved to output/{args.client}/", "OK")


if __name__ == "__main__":
    main()
