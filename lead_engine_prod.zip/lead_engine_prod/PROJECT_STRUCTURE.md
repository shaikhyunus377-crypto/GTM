
LEAD QUALIFICATION ENGINE — Full Project Structure
====================================================

lead_engine/
│
├── main.py                          ← Entry point. Run: python main.py --client dental_clinic_sa
│
├── core/
│   ├── pipeline.py                  ← Master orchestrator. Calls all modules in order.
│   ├── output.py                    ← Saves results to Excel / CSV with formatting
│   ├── logger.py                    ← Simple timestamped logging
│   └── __init__.py
│
├── modules/                         ← Each module = one gate or one enrichment step
│   ├── scraper.py                   ← MODULE 1: Google Maps scraping (Apify API)
│   ├── website_checker.py           ← MODULE 2: Tech stack, age, mobile score
│   ├── form_detector.py             ← MODULE 3: Has form? Own vs 3rd party?
│   ├── cro_analyzer.py              ← MODULE 4: CRO/accessibility issues on form (GPT)
│   ├── gate_engine.py               ← MODULE 5: Runs client's custom gates from config
│   ├── owner_finder.py              ← MODULE 6: Finds owner name (About page + GPT)
│   ├── email_finder.py              ← MODULE 7: Email waterfall (scrape → Hunter → WHOIS)
│   ├── ai_writer.py                 ← MODULE 8: Generates personalized email opener (GPT)
│   └── __init__.py
│
├── config/
│   ├── settings.py                  ← API keys, global constants
│   └── third_party_platforms.py     ← List of 3rd party form platforms to detect
│
├── clients/                         ← One folder per client
│   ├── sample_dental/
│   │   ├── config.json              ← Client ICP: niche, city, gates, output columns
│   │   └── runs/                    ← History of past pipeline runs
│   │
│   ├── web_design_agency/
│   │   └── config.json
│   │
│   └── seo_agency_hvac/
│       └── config.json
│
├── output/                          ← All deliverables saved here
│   ├── sample_dental/
│   │   ├── leads_2025_05_02.xlsx    ← Weekly Excel report sent to client
│   │   └── leads_2025_05_02.csv
│   └── ...
│
├── tests/
│   ├── test_form_detector.py
│   ├── test_email_finder.py
│   └── test_cro_analyzer.py
│
└── requirements.txt                 ← All dependencies

====================================================
WHAT EACH MODULE DOES
====================================================

MODULE 1 — scraper.py
  Input : niche (str), city (str), max_results (int)
  Output: list of raw business dicts
  Method: Apify Google Maps Actor API
  Data  : name, address, phone, website, rating, review_count, hours

MODULE 2 — website_checker.py
  Input : website URL
  Output: {cms, domain_age_years, mobile_score, site_era}
  Method: builtwith + python-whois + Google PageSpeed API
  Gate  : flags sites with mobile_score < 50 or domain_age > 4 years

MODULE 3 — form_detector.py
  Input : website URL
  Output: {has_form, is_own, platform, form_html}
  Method: Playwright — visits site, clicks booking button, checks redirect URL
  Gate  : skips if no form OR if redirects to Zocdoc/PatientPop/PlanetDDS etc.

MODULE 4 — cro_analyzer.py
  Input : URL, form_html
  Output: {issues_found[], biggest_issue, severity, estimated_conversion_loss}
  Method: GPT-4o-mini analyzes form HTML for 10 specific CRO/a11y problems
  Gate  : skips if no issues found (form is clean — not your client's customer)

MODULE 5 — gate_engine.py
  Input : business dict, gates[] from client config
  Output: {passed: bool, reason: str}
  Method: loops through config gates, applies each filter function
  Gates : rating_filter, review_count_filter, independent_check, owner_name_required

MODULE 6 — owner_finder.py
  Input : website URL, business name
  Output: owner name string or None
  Method: 1. Scrape /about /team /meet-the-doctor pages → regex for "Dr. X Y"
           2. GPT extraction from homepage HTML
           3. Return None if not found (lead still qualifies, opener won't use name)

MODULE 7 — email_finder.py
  Input : website URL, owner name, domain
  Output: (email, source) or (None, "not_found")
  Method: 1. Scrape mailto links from website pages (free)
           2. Hunter.io Domain Search API (~$0.003/call)
           3. Hunter.io Email Finder with owner name (~$0.003/call)
           4. WHOIS registrant email (free)

MODULE 8 — ai_writer.py
  Input : business_name, owner_name, cro_data, site_data
  Output: personalized 1-sentence email opener (max 25 words)
  Method: GPT-4o-mini with strict prompt rules
  Rules : no "I noticed", references the SPECIFIC issue, implies money loss

====================================================
CLIENT CONFIG FORMAT
====================================================

{
  "client_name": "dental_clinic_sa",
  "niche": "dental clinic",
  "city": "San Antonio TX",
  "gates": [
    {"module": "rating_filter",       "min": 3.5, "max": 4.5},
    {"module": "review_count_filter", "min": 10,  "max": 500},
    {"module": "independent_check"},
    {"module": "owner_name_required"}
  ],
  "output_columns": ["business_name", "owner_email", "top_cro_issue", ...],
  "delivery": {
    "format": "excel",
    "frequency": "weekly",
    "leads_per_batch": 100
  }
}

Different client = different config.json. Same code runs underneath.

====================================================
COST PER 100 QUALIFIED LEADS (estimated)
====================================================

Apify Google Maps scraping (300 raw to get 100 qualified) : ~$3.00
Hunter.io email searches (100 calls × $0.003)             : ~$0.30
GPT-4o-mini CRO analysis (100 calls × $0.001)            : ~$0.10
GPT-4o-mini email openers (100 calls × $0.001)           : ~$0.10
PageSpeed API (free tier, 25,000 calls/day)               : $0.00
Website scraping (requests + BeautifulSoup, free)         : $0.00
                                                    TOTAL : ~$3.50

Revenue per 100-lead batch: $150–$300
Margin: 98%+
