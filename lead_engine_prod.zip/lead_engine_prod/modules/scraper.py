"""
modules/scraper.py
MODULE 1 — Google Maps Scraper

Two methods:
  A) Apify API  — production, reliable, $2–5 per 200 results (recommended)
  B) Playwright — free fallback, may break when Google changes selectors

Returns a list of raw business dicts with:
  name, address, phone, website, rating, reviewsCount, domain
"""

import time
import re
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config.settings import APIFY_API_TOKEN, REQUEST_TIMEOUT
from core.logger import log


# ── Helper ────────────────────────────────────────────────────────────────────

def extract_domain(url: str) -> str:
    """Pull just the domain from a full URL."""
    if not url:
        return ""
    url = url.replace("https://", "").replace("http://", "").replace("www.", "")
    return url.split("/")[0].split("?")[0].lower()


def clean_results(raw_items: list) -> list:
    """Normalise field names and add domain field."""
    cleaned = []
    for item in raw_items:
        website = item.get("website") or item.get("url") or ""
        if not website:
            continue  # no website = can't check form, skip immediately

        cleaned.append({
            "name":         item.get("title") or item.get("name", ""),
            "address":      item.get("address") or item.get("formatted_address", ""),
            "phone":        item.get("phone") or item.get("formatted_phone_number", ""),
            "website":      website,
            "domain":       extract_domain(website),
            "rating":       float(item.get("totalScore") or item.get("rating") or 0),
            "reviewsCount": int(item.get("reviewsCount") or item.get("user_ratings_total") or 0),
            "category":     item.get("categoryName") or item.get("types", [""])[0],
            "place_id":     item.get("placeId") or item.get("place_id", ""),
            "maps_url":     item.get("url") or "",
        })
    return cleaned


# ══════════════════════════════════════════════════════════════════════════════
# METHOD A — Apify API (RECOMMENDED for production)
# ══════════════════════════════════════════════════════════════════════════════

def scrape_via_apify(niche: str, city: str, max_results: int = 200) -> list:
    """
    Uses Apify's maintained Google Maps scraper actor.
    Handles proxies, CAPTCHAs, and selector changes automatically.
    Cost: ~$2–5 per 200 results.

    Docs: https://apify.com/compass/crawler-google-places
    """
    try:
        from apify_client import ApifyClient
    except ImportError:
        log("apify-client not installed. Run: pip install apify-client", "ERROR")
        return []

    if not APIFY_API_TOKEN or APIFY_API_TOKEN == "YOUR_APIFY_TOKEN":
        log("APIFY_API_TOKEN not set in config/settings.py", "ERROR")
        return []

    client = ApifyClient(APIFY_API_TOKEN)
    query  = f"{niche} in {city}"
    log(f"Apify scraping: '{query}' (max {max_results})")

    run = client.actor("compass/crawler-google-places").call(
        run_input={
            "searchStringsArray":        [query],
            "maxCrawledPlacesPerSearch": max_results,
            "language":                  "en",
            "maxImages":                 0,       # don't waste credits on images
            "includeWebResults":         False,
            "exportPlaceUrls":           False,
        }
    )

    items = list(client.dataset(run["defaultDatasetId"]).iterate_items())
    log(f"Apify returned {len(items)} raw results")
    return clean_results(items)


# ══════════════════════════════════════════════════════════════════════════════
# METHOD B — Playwright self-built scraper (FREE fallback)
# ══════════════════════════════════════════════════════════════════════════════

def scrape_via_playwright(niche: str, city: str, max_results: int = 200) -> list:
    """
    Free alternative using a headless browser.
    WARNING: Google changes selectors. This may break periodically.
    Use Apify in production; use this for testing / low volume.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        log("playwright not installed. Run: pip install playwright && playwright install chromium", "ERROR")
        return []

    query   = f"{niche} in {city}"
    results = []

    log(f"Playwright scraping: '{query}'")

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-setuid-sandbox"]
        )
        context = browser.new_context(
            # mimic a real user agent
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 900},
        )
        page = context.new_page()

        # ── Navigate to Google Maps ───────────────────────────────────────────
        page.goto("https://www.google.com/maps", timeout=30000)
        page.wait_for_selector("#searchboxinput", timeout=15000)
        time.sleep(2)

        # ── Type query and search ─────────────────────────────────────────────
        search_box = page.locator("#searchboxinput")
        search_box.fill(query)
        search_box.press("Enter")
        time.sleep(4)

        # ── Scroll results panel to load more ────────────────────────────────
        max_scrolls   = max(10, max_results // 15)
        scroll_count  = 0

        try:
            feed = page.locator('div[role="feed"]')
            feed.wait_for(timeout=10000)

            while scroll_count < max_scrolls:
                page.evaluate(
                    '(el) => el.scrollTop = el.scrollHeight',
                    feed.element_handle()
                )
                time.sleep(2)
                scroll_count += 1

                # stop if "end of results" text appears
                if page.locator("text=You've reached the end").count() > 0:
                    log(f"Reached end of results after {scroll_count} scrolls")
                    break

        except Exception as e:
            log(f"Feed scroll error: {e}", "ERROR")

        # ── Extract each listing card ─────────────────────────────────────────
        cards = page.locator('div[role="article"]').all()
        log(f"Found {len(cards)} listing cards")

        for card in cards[:max_results]:
            try:
                name_el = card.locator(".fontHeadlineSmall span")
                name    = name_el.inner_text() if name_el.count() > 0 else ""
                if not name:
                    continue

                # click card to reveal full details in side panel
                card.click()
                time.sleep(2)

                # ── Pull details from side panel ──────────────────────────
                panel = page.locator('div[role="main"]')

                # rating
                rating_el = panel.locator('span[aria-hidden="true"]').first
                rating_text = rating_el.inner_text() if rating_el.count() > 0 else "0"
                try:
                    rating = float(rating_text.replace(",", "."))
                except ValueError:
                    rating = 0.0

                # review count
                review_el = panel.locator('span[aria-label*="review"]').first
                review_text = review_el.get_attribute("aria-label") or "0"
                review_count = int(re.sub(r"[^\d]", "", review_text) or "0")

                # phone
                phone_el = panel.locator('button[data-item-id*="phone"]').first
                phone = ""
                if phone_el.count() > 0:
                    phone = phone_el.get_attribute("aria-label") or ""
                    phone = phone.replace("Phone:", "").strip()

                # website
                website_el = panel.locator('a[data-item-id="authority"]').first
                website = ""
                if website_el.count() > 0:
                    website = website_el.get_attribute("href") or ""

                # address
                address_el = panel.locator('button[data-item-id*="address"]').first
                address = ""
                if address_el.count() > 0:
                    address = address_el.get_attribute("aria-label") or ""
                    address = address.replace("Address:", "").strip()

                if not website:
                    continue  # no website = skip

                results.append({
                    "name":         name,
                    "address":      address,
                    "phone":        phone,
                    "website":      website,
                    "domain":       extract_domain(website),
                    "rating":       rating,
                    "reviewsCount": review_count,
                    "category":     "",
                    "place_id":     "",
                    "maps_url":     page.url,
                })

            except Exception as e:
                log(f"Card extraction error: {e}", "ERROR")
                continue

        browser.close()

    log(f"Playwright returned {len(results)} results with websites")
    return results


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC FUNCTION — called by pipeline.py
# ══════════════════════════════════════════════════════════════════════════════

def scrape_google_maps(niche: str, city: str, max_results: int = 200) -> list:
    """
    Main entry point for Module 1.
    Tries Apify first (production), falls back to Playwright (free/testing).
    """
    if APIFY_API_TOKEN and APIFY_API_TOKEN != "YOUR_APIFY_TOKEN":
        return scrape_via_apify(niche, city, max_results)
    else:
        log("No Apify token — using Playwright scraper (free mode)", "INFO")
        return scrape_via_playwright(niche, city, max_results)


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Test with Playwright (no API key needed)
    results = scrape_google_maps("dental clinic", "San Antonio TX", max_results=10)
    print(f"\nResults: {len(results)}")
    for r in results[:3]:
        print(f"  {r['name']} | {r['rating']}★ | {r['website']}")
