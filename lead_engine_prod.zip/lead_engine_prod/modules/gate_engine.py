"""
modules/gate_engine.py
MODULE 5 — Custom Gate Engine

Runs the client's custom qualification gates from config.json.
Each gate is a function that returns (passed: bool, reason: str).

Available gates:
  - rating_filter         min/max Google rating
  - review_count_filter   min/max number of reviews
  - independent_check     not a chain/franchise
  - owner_name_required   owner name must be findable
  - mobile_score_filter   minimum mobile PageSpeed score
  - site_age_filter       domain must be older than N years
"""

import re
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from core.logger import log

# ── Known chain/franchise keywords ────────────────────────────────────────────
CHAIN_SIGNALS = [
    "aspen dental", "western dental", "pacific dental", "bright now",
    "smile doctors", "dental care alliance", "dental works", "great expressions",
    "community health", "va dental", "army dental", "navy dental",
    "university dental", "school of dentistry", "dental college",
    "communicare", "haven for hope", "nonprofit", "low-income",
    "federally qualified", "fqhc",
]


# ── Individual gate functions ─────────────────────────────────────────────────

def gate_rating_filter(biz: dict, config: dict) -> tuple:
    rating  = biz.get("rating", 0)
    minimum = config.get("min", 3.5)
    maximum = config.get("max", 4.7)
    if minimum <= rating <= maximum:
        return True, f"Rating {rating} in range {minimum}–{maximum}"
    return False, f"Rating {rating} out of range {minimum}–{maximum}"


def gate_review_count_filter(biz: dict, config: dict) -> tuple:
    count   = biz.get("reviewsCount", 0)
    minimum = config.get("min", 10)
    maximum = config.get("max", 1000)
    if minimum <= count <= maximum:
        return True, f"Review count {count} in range {minimum}–{maximum}"
    return False, f"Review count {count} out of range {minimum}–{maximum}"


def gate_independent_check(biz: dict, config: dict) -> tuple:
    name_lower = (biz.get("name") or "").lower()
    addr_lower = (biz.get("address") or "").lower()
    combined   = name_lower + " " + addr_lower

    for signal in CHAIN_SIGNALS:
        if signal in combined:
            return False, f"Chain/org detected: '{signal}'"

    return True, "Appears to be independent clinic"


def gate_owner_name_required(biz: dict, config: dict) -> tuple:
    # Owner name gets filled in by Module 6 before gates run in full pipeline.
    # This gate just checks if the field was populated.
    owner = biz.get("owner_name") or ""
    if owner and owner != "N/A":
        return True, f"Owner name found: {owner}"
    return False, "Owner name not found"


def gate_mobile_score_filter(biz: dict, config: dict) -> tuple:
    score   = (biz.get("site_data") or {}).get("mobile_score")
    minimum = config.get("max", 70)   # "max" means ceiling here — skip if score above this
    if score is None:
        return True, "Mobile score unavailable — skipping gate"
    if score <= minimum:
        return True, f"Mobile score {score} qualifies (≤ {minimum})"
    return False, f"Mobile score {score} too good — site not your target"


def gate_site_age_filter(biz: dict, config: dict) -> tuple:
    age     = (biz.get("site_data") or {}).get("domain_age_years", 0)
    minimum = config.get("min_years", 3)
    if age >= minimum:
        return True, f"Domain age {age} years qualifies"
    return False, f"Domain age {age} years too new (min {minimum})"


# ── Gate registry ─────────────────────────────────────────────────────────────
GATE_REGISTRY = {
    "rating_filter":        gate_rating_filter,
    "review_count_filter":  gate_review_count_filter,
    "independent_check":    gate_independent_check,
    "owner_name_required":  gate_owner_name_required,
    "mobile_score_filter":  gate_mobile_score_filter,
    "site_age_filter":      gate_site_age_filter,
}


# ── Public function ───────────────────────────────────────────────────────────

def run_gates(biz: dict, gates: list) -> dict:
    """
    Run all gates defined in client config.
    Returns {passed: bool, reason: str}

    gates format (from config.json):
      [
        {"module": "rating_filter", "min": 3.5, "max": 4.5},
        {"module": "independent_check"},
        ...
      ]
    """
    for gate_config in gates:
        module_name = gate_config.get("module")
        gate_fn     = GATE_REGISTRY.get(module_name)

        if not gate_fn:
            log(f"Unknown gate module: {module_name}", "ERROR")
            continue

        passed, reason = gate_fn(biz, gate_config)
        if not passed:
            return {"passed": False, "reason": f"{module_name}: {reason}"}

    return {"passed": True, "reason": "All gates passed"}
