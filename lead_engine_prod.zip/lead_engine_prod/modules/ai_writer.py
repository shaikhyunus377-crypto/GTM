"""
modules/ai_writer.py
MODULE 8 — AI Email Opener Generator

Takes the specific issue found + site data and generates
a 1-sentence personalized cold email opener per lead.

Rules enforced via prompt:
  - Max 25 words
  - References the SPECIFIC issue found (not generic)
  - Implies money loss / missed patients
  - Sounds human, not robotic
  - Never starts with "I noticed" or "I saw"
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config.settings import OPENAI_API_KEY, GPT_MODEL
from core.logger import log


EXAMPLES = """
Good openers (use these as style reference):
- "Your booking form shows patients a live error right now — submissions aren't going through."
- "Patients switch your site to Spanish, then hit an English-only booking form and leave."
- "Your $79 new patient special is on every page — but disappears the moment someone clicks Book."
- "Your site loads in 11 seconds on mobile — 70% of patients searching for a dentist are on phone."
- "Patients submit your booking form and get no confirmation — most assume it failed and call elsewhere."
"""


def generate_opener(
    business_name: str,
    owner_name: str,
    cro_data: dict,
    site_data: dict,
) -> str:

    if not OPENAI_API_KEY or OPENAI_API_KEY == "YOUR_OPENAI_API_KEY":
        # fallback: build rule-based opener from CRO data
        return _fallback_opener(business_name, cro_data, site_data)

    biggest_issue = cro_data.get("biggest_issue", "")
    mobile_score  = site_data.get("mobile_score")
    all_issues    = cro_data.get("issues_found", [])

    if not biggest_issue and not all_issues:
        return ""

    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_API_KEY)

        prompt = f"""
Write ONE cold email opening sentence for a CRO consultant
reaching out to this dental clinic owner.

Business: {business_name}
Owner: {owner_name or "the owner"}
Main issue: {biggest_issue}
Other issues: {", ".join(all_issues[:3])}
Mobile score: {mobile_score or "unknown"}/100

{EXAMPLES}

Rules (strictly follow):
- ONE sentence, maximum 25 words
- Reference the SPECIFIC issue (not generic "website problems")
- Imply lost patients or lost money — make it feel real
- Sound like a human peer, not a sales pitch
- Do NOT start with: I noticed / I saw / I checked / I found / Hi / Hello
- Do NOT use the owner's name (that goes in the email greeting separately)

Return only the sentence. Nothing else.
"""
        resp = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=60,
            temperature=0.7,
        )
        opener = resp.choices[0].message.content.strip().strip('"')
        log(f"AI opener generated: {opener[:60]}...", "OK")
        return opener

    except Exception as e:
        log(f"AI writer error: {e}", "ERROR")
        return _fallback_opener(business_name, cro_data, site_data)


def _fallback_opener(business_name: str, cro_data: dict, site_data: dict) -> str:
    """Rule-based opener when OpenAI is unavailable."""
    issue = cro_data.get("biggest_issue", "")
    score = site_data.get("mobile_score")

    if "confirmation" in issue.lower():
        return "Patients submit your booking form and get no confirmation — most assume it failed and move on."
    if "mobile" in issue.lower() or (score and score < 40):
        return f"Your site loads slowly on mobile — most dental searches happen on phone, not desktop."
    if "spanish" in issue.lower() or "language" in issue.lower():
        return "Your site has a Spanish toggle but the booking form is English only — patients drop off there."
    if "button" in issue.lower() or "cta" in issue.lower():
        return "Your booking button says 'Submit' — the lowest-converting CTA text possible on a contact form."
    if "fields" in issue.lower() or "insurance" in issue.lower():
        return "Your booking form asks for insurance details upfront — most patients abandon before submitting."
    if issue:
        return f"Found a specific issue on your booking form that's likely costing you new patient requests."
    return ""
