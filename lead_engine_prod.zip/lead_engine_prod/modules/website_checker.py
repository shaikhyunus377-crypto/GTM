"""
modules/website_checker.py — MODULE 2
Website Health Checker — no external dependencies beyond requests.
Detects: CMS, domain age, PageSpeed mobile score, site era.
"""
import requests, re, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config.settings import GOOGLE_API_KEY, REQUEST_TIMEOUT
from core.logger import log

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"}
MODERN_SIGNALS   = ["webflow", "next.js", "nextjs", "react", "vue", "nuxt", "gatsby", "astro"]
OUTDATED_SIGNALS = ["jquery/1.", "jquery/2.", "bootstrap/3", "wp-content", "wp-includes"]

def detect_cms(html: str) -> str:
    h = html.lower()
    if "wp-content" in h or "wp-includes" in h:
        m = re.search(r'wordpress[\s/]+([\d.]+)', h)
        return f"WordPress {m.group(1)}".strip() if m else "WordPress"
    if "squarespace" in h or "sqsp" in h: return "Squarespace"
    if "wixsite" in h or "wix.com" in h:  return "Wix"
    if "webflow" in h:                     return "Webflow"
    if "shopify" in h:                     return "Shopify"
    if "joomla" in h:                      return "Joomla"
    if "drupal" in h:                      return "Drupal"
    if "ghost.io" in h:                    return "Ghost"
    return "Custom / Unknown"

def get_domain_age(domain: str) -> float:
    try:
        import whois
        from datetime import datetime
        w = whois.whois(domain)
        c = w.creation_date
        if isinstance(c, list): c = c[0]
        if c: return round((datetime.now() - c).days / 365, 1)
    except Exception: pass
    return 0.0

def get_pagespeed_score(url: str):
    if not GOOGLE_API_KEY: return None
    try:
        r = requests.get(
            f"https://www.googleapis.com/pagespeedonline/v5/runPagespeed"
            f"?url={url}&strategy=mobile&key={GOOGLE_API_KEY}",
            timeout=REQUEST_TIMEOUT
        )
        return int(r.json()["lighthouseResult"]["categories"]["performance"]["score"] * 100)
    except Exception: return None

def classify_era(html: str, age: float, score) -> str:
    h = html.lower()
    modern   = sum(1 for s in MODERN_SIGNALS   if s in h)
    outdated = sum(1 for s in OUTDATED_SIGNALS if s in h)
    slow     = score is not None and score < 50
    if modern >= 2 and not slow:           return "Modern"
    if outdated >= 2 or (age > 4 and slow): return "Outdated"
    return "Mixed"

def check_website(url: str) -> dict:
    result = {"cms": "Unknown", "domain_age_years": 0.0, "domain_old": False,
              "mobile_score": None, "mobile_slow": False, "site_era": "Unknown"}
    try:
        r      = requests.get(url, timeout=REQUEST_TIMEOUT, headers=HEADERS)
        html   = r.text
        domain = url.replace("https://","").replace("http://","").split("/")[0]
        result["cms"]              = detect_cms(html)
        result["domain_age_years"] = get_domain_age(domain)
        result["domain_old"]       = result["domain_age_years"] > 4
        result["mobile_score"]     = get_pagespeed_score(url)
        result["mobile_slow"]      = bool(result["mobile_score"] and result["mobile_score"] < 50)
        result["site_era"]         = classify_era(html, result["domain_age_years"], result["mobile_score"])
    except Exception as e:
        log(f"Website check failed: {url} — {e}", "ERROR")
    return result
