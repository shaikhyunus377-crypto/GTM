"""
modules/cro_analyzer.py
MODULE 4 — CRO + Accessibility Analyzer

Takes the form HTML from Module 3 and asks GPT to find
specific conversion problems.

Returns:
  {
    "issues_found":              list[str],
    "biggest_issue":             str,
    "severity":                  "HIGH" / "MEDIUM" / "LOW",
    "estimated_conversion_loss": str,
  }
"""

import json
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config.settings import OPENAI_API_KEY, GPT_MODEL, GPT_MAX_TOKENS
from core.logger import log

CRO_CHECKLIST = """
Check the booking form HTML for these exact problems:

1.  No confirmation message after submit (patient doesn't know it worked)
2.  Generic CTA button text ("Submit" / "Send" instead of "Book My Appointment")
3.  Too many required fields — more than 4 fields upfront
4.  No date or time picker — patient submits a blank request into a void
5.  No trust signals near the form (no rating, no "we'll call you in X hours")
6.  No phone number alternative shown near the form
7.  Form fields missing labels (accessibility violation)
8.  Low contrast button colour (hard to see, especially on mobile)
9.  Language mismatch — site has Spanish/other language content but form is English only
10. No error validation messages when fields are left blank
11. Form requires insurance or DOB before patient knows if clinic accepts them
12. No privacy note near email field ("we never spam")
"""


def analyze_cro(url: str, form_html: str) -> dict:
    empty = {
        "issues_found":              [],
        "biggest_issue":             "",
        "severity":                  "LOW",
        "estimated_conversion_loss": "0%",
    }

    if not form_html:
        return empty

    if not OPENAI_API_KEY or OPENAI_API_KEY == "YOUR_OPENAI_API_KEY":
        log("OPENAI_API_KEY not set — CRO analysis skipped", "ERROR")
        return empty

    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_API_KEY)

        prompt = f"""
You are a conversion rate optimization expert reviewing a local dental clinic booking form.

URL: {url}

Form HTML:
{form_html[:2500]}

{CRO_CHECKLIST}

Respond ONLY with a valid JSON object. No explanation. No markdown. Just JSON.

Format:
{{
  "issues_found": ["exact issue 1", "exact issue 2"],
  "biggest_issue": "single most impactful problem in one sentence",
  "severity": "HIGH or MEDIUM or LOW",
  "estimated_conversion_loss": "e.g. 20-30%"
}}

Rules:
- Only include issues you can actually confirm from the HTML
- biggest_issue must be specific, not generic ("no confirmation message" not "bad UX")
- If no issues found, return empty issues_found list
"""

        response = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=GPT_MAX_TOKENS,
            temperature=0.2,
        )

        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        return json.loads(raw)

    except json.JSONDecodeError as e:
        log(f"CRO JSON parse error: {e}", "ERROR")
        return empty
    except Exception as e:
        log(f"CRO analysis error: {e}", "ERROR")
        return empty


if __name__ == "__main__":
    sample_html = """
    <form method="post">
      <input type="text" placeholder="Your Name" required>
      <input type="email" placeholder="Email" required>
      <input type="text" placeholder="Date of Birth" required>
      <input type="text" placeholder="Insurance Provider" required>
      <input type="text" placeholder="Policy Number" required>
      <textarea placeholder="Message"></textarea>
      <button type="submit">Submit</button>
    </form>
    """
    result = analyze_cro("https://example-dental.com/contact", sample_html)
    print(json.dumps(result, indent=2))
