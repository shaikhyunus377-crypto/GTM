"""
modules/owner_finder.py
MODULE 6 — Owner Name Finder

Waterfall approach:
  1. Scrape /about, /team, /meet-the-doctor pages → regex for "Dr. X Y"
  2. GPT extraction from homepage text
  3. Return None if not found (lead still qualifies)

Returns: owner name string or None
"""

import re
import requests
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config.settings import OPENAI_API_KEY, GPT_MODEL, REQUEST_TIMEOUT, HOMEPAGE_TEXT_CHARS
from core.logger import log
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 Chrome/120.0.0.0 Safari/537.36"}

ABOUT_PATHS = [
    "/about", "/about-us", "/our-team", "/team",
    "/meet-the-doctor", "/meet-dr", "/meet-our-dentist",
    "/meet-our-team", "/staff", "/doctors", "/provider",
]

DR_PATTERN = re.compile(
    r'\bDr\.?\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})',
    re.UNICODE
)


def scrape_about_page(base_url: str) -> str | None:
    for path in ABOUT_PATHS:
        try:
            r = requests.get(
                base_url.rstrip("/") + path,
                timeout=REQUEST_TIMEOUT,
                headers=HEADERS
            )
            if r.status_code != 200:
                continue
            soup  = BeautifulSoup(r.text, "html.parser")
            text  = soup.get_text(" ", strip=True)
            match = DR_PATTERN.search(text)
            if match:
                return "Dr. " + match.group(1).strip()
        except Exception:
            continue
    return None


def extract_with_gpt(url: str, business_name: str, homepage_text: str) -> str | None:
    if not OPENAI_API_KEY or OPENAI_API_KEY == "YOUR_OPENAI_API_KEY":
        return None
    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_API_KEY)
        prompt = f"""
Business: {business_name}
Website: {url}
Page text: {homepage_text[:HOMEPAGE_TEXT_CHARS]}

Extract the owner or primary dentist's full name from this text.
Return ONLY the name (e.g. "Dr. Sarah Johnson"). If not found, return exactly: NOT_FOUND
"""
        resp = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=30,
            temperature=0,
        )
        name = resp.choices[0].message.content.strip()
        return None if name == "NOT_FOUND" else name
    except Exception:
        return None


def find_owner(website_url: str, business_name: str) -> str | None:
    # Step 1 — About page scrape
    owner = scrape_about_page(website_url)
    if owner:
        log(f"Owner found (about page): {owner}", "OK")
        return owner

    # Step 2 — GPT from homepage
    try:
        r    = requests.get(website_url, timeout=REQUEST_TIMEOUT, headers=HEADERS)
        soup = BeautifulSoup(r.text, "html.parser")
        text = soup.get_text(" ", strip=True)

        # quick regex attempt on homepage first (free, fast)
        match = DR_PATTERN.search(text)
        if match:
            owner = "Dr. " + match.group(1).strip()
            log(f"Owner found (homepage regex): {owner}", "OK")
            return owner

        # GPT fallback
        owner = extract_with_gpt(website_url, business_name, text)
        if owner:
            log(f"Owner found (GPT): {owner}", "OK")
            return owner

    except Exception:
        pass

    log(f"Owner not found for: {business_name}", "SKIP")
    return None
