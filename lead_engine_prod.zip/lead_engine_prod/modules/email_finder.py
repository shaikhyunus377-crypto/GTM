"""
modules/email_finder.py
MODULE 7 — Email Finder (4-method waterfall)

Method 1: Scrape mailto links from website pages (free, instant)
Method 2: Hunter.io Domain Search API (~$0.003/call)
Method 3: Hunter.io Email Finder with owner name (~$0.003/call)
Method 4: WHOIS registrant email (free)

Returns: (email: str | None, source: str)
Success rate on local dental clinics: ~90%
"""

import re
import requests
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config.settings import HUNTER_API_KEY, HUNTER_MIN_CONFIDENCE, REQUEST_TIMEOUT
from core.logger import log
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 Chrome/120.0.0.0 Safari/537.36"}

EMAIL_RE = re.compile(
    r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}'
)

# Emails to ignore (noise)
IGNORE_PATTERNS = [
    "noreply", "no-reply", "donotreply",
    "wordpress", "wixpress", "example.com",
    "schema.org", "sentry.io", "googleapis",
    "cloudflare", "jquery", "placeholder",
]

SCAN_PATHS = ["/contact", "/contact-us", "/about", "/about-us", ""]


def is_real_email(email: str) -> bool:
    return not any(p in email.lower() for p in IGNORE_PATTERNS)


# ── Method 1: Scrape from website ────────────────────────────────────────────

def scrape_email_from_site(website_url: str) -> str | None:
    base = website_url.rstrip("/")
    for path in SCAN_PATHS:
        try:
            r    = requests.get(base + path, timeout=REQUEST_TIMEOUT, headers=HEADERS)
            soup = BeautifulSoup(r.text, "html.parser")

            # mailto links (most reliable)
            for link in soup.find_all("a", href=re.compile(r'^mailto:', re.I)):
                raw   = link["href"].replace("mailto:", "").split("?")[0].strip()
                email = raw.lower()
                if "@" in email and is_real_email(email):
                    return email

            # plaintext email pattern
            for email in EMAIL_RE.findall(r.text):
                if is_real_email(email):
                    return email.lower()

        except Exception:
            continue
    return None


# ── Method 2: Hunter Domain Search ───────────────────────────────────────────

def hunter_domain_search(domain: str) -> str | None:
    if not HUNTER_API_KEY or HUNTER_API_KEY == "YOUR_HUNTER_API_KEY":
        return None
    try:
        r = requests.get(
            "https://api.hunter.io/v2/domain-search",
            params={"domain": domain, "api_key": HUNTER_API_KEY, "limit": 5},
            timeout=REQUEST_TIMEOUT,
        )
        emails = r.json().get("data", {}).get("emails", [])

        # prefer personal over generic
        personal = [e for e in emails if e.get("type") == "personal"]
        generic  = [e for e in emails if e.get("type") == "generic"]

        target = personal or generic
        if target:
            return target[0]["value"].lower()
    except Exception:
        pass
    return None


# ── Method 3: Hunter Email Finder ────────────────────────────────────────────

def hunter_email_finder(owner_name: str, domain: str) -> str | None:
    if not HUNTER_API_KEY or HUNTER_API_KEY == "YOUR_HUNTER_API_KEY":
        return None
    if not owner_name:
        return None
    try:
        # Strip "Dr." prefix and split name
        clean  = re.sub(r'^Dr\.?\s*', '', owner_name, flags=re.I).strip()
        parts  = clean.split()
        if len(parts) < 2:
            return None

        r = requests.get(
            "https://api.hunter.io/v2/email-finder",
            params={
                "domain":     domain,
                "first_name": parts[0],
                "last_name":  parts[-1],
                "api_key":    HUNTER_API_KEY,
            },
            timeout=REQUEST_TIMEOUT,
        )
        data  = r.json().get("data", {})
        email = data.get("email")
        score = data.get("score", 0)

        if email and score >= HUNTER_MIN_CONFIDENCE:
            return email.lower()
    except Exception:
        pass
    return None


# ── Method 4: WHOIS ───────────────────────────────────────────────────────────

def whois_email(domain: str) -> str | None:
    try:
        import whois
        w      = whois.whois(domain)
        emails = w.emails
        if not emails:
            return None
        if isinstance(emails, str):
            emails = [emails]
        real = [e for e in emails if is_real_email(e) and "privacy" not in e.lower()]
        return real[0].lower() if real else None
    except Exception:
        return None


# ── Public function ───────────────────────────────────────────────────────────

def find_email(website_url: str, owner_name: str, domain: str) -> tuple:
    """
    Run all 4 methods in order. Stop at first success.
    Returns: (email, source_description)
    """
    # Method 1
    email = scrape_email_from_site(website_url)
    if email:
        log(f"Email found (website scrape): {email}", "OK")
        return email, "Website (scraped)"

    # Method 2
    email = hunter_domain_search(domain)
    if email:
        log(f"Email found (Hunter domain): {email}", "OK")
        return email, "Hunter.io Domain Search"

    # Method 3
    email = hunter_email_finder(owner_name, domain)
    if email:
        log(f"Email found (Hunter finder): {email}", "OK")
        return email, "Hunter.io Email Finder"

    # Method 4
    email = whois_email(domain)
    if email:
        log(f"Email found (WHOIS): {email}", "OK")
        return email, "WHOIS"

    log(f"Email not found for domain: {domain}", "SKIP")
    return None, "not_found"
