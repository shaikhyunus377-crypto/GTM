"""
modules/form_detector.py
MODULE 3 — Booking Form Detector

This is your biggest competitive advantage.
Every other tool stops at the website URL.
This module actually VISITS the site and determines:

  1. Does a booking/appointment form exist?
  2. Is it their OWN form or a 3rd party platform?
  3. What platform is it (Zocdoc, PlanetDDS, Weave, etc.)?
  4. Returns the raw form HTML for CRO analysis in Module 4.

Returns:
  {
    "has_form":   bool,
    "is_own":     bool,
    "platform":   str,   # "Zocdoc" / "Own (WordPress CF7)" / "None found"
    "form_html":  str,   # raw HTML of the form (for CRO analyzer)
    "form_url":   str,   # URL where form was found
    "verdict":    str,   # human-readable summary
  }
"""

import time
import re
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from config.third_party_platforms import ALL_THIRD_PARTY
from config.settings import REQUEST_TIMEOUT
from core.logger import log


# ── Keywords that trigger a booking form search ───────────────────────────────
BOOKING_KEYWORDS = [
    "book",
    "appointment",
    "schedule",
    "request an appointment",
    "request appointment",
    "book now",
    "book online",
    "get started",
    "new patient",
    "contact us",
]

# ── Common URL paths where forms live ─────────────────────────────────────────
FORM_PATHS = [
    "/appointment",
    "/appointments",
    "/book",
    "/book-appointment",
    "/book-now",
    "/booking",
    "/schedule",
    "/schedule-appointment",
    "/new-patient",
    "/new-patients",
    "/contact",
    "/contact-us",
    "/request-appointment",
    "/patient-forms",
    "/get-started",
]

# ── Known own-form platform fingerprints ─────────────────────────────────────
OWN_FORM_SIGNALS = {
    "WordPress Contact Form 7": ["wpcf7", "cf7", "contact-form-7"],
    "WordPress Gravity Forms":  ["gform", "gravity-forms", "gravityforms"],
    "WordPress WPForms":        ["wpforms"],
    "WordPress Ninja Forms":    ["nf-form", "ninja-forms"],
    "Squarespace Native":       ["squarespace-form", "sqs-forms"],
    "Webflow Native":           ["wf-form", "webflow"],
    "Wix Native":               ["wix-form", "wixforms"],
    "HubSpot Embedded Form":    ["hs-form", "hubspot", "hbspt.forms"],
    "Elementor Form":           ["elementor-form"],
    "Custom HTML Form":         ["<form ", "method=\"post\""],
}


def is_third_party_url(url: str) -> tuple:
    """
    Check if a URL belongs to a known 3rd party booking platform.
    Returns (True, platform_name) or (False, None)
    """
    url_lower = url.lower()
    for platform in ALL_THIRD_PARTY:
        if platform in url_lower:
            # Clean up platform name for display
            name = platform.split(".")[0].title()
            return True, name
    return False, None


def is_third_party_html(html: str) -> tuple:
    """
    Check if page HTML embeds a known 3rd party booking platform.
    Returns (True, platform_name) or (False, None)
    """
    html_lower = html.lower()
    for platform in ALL_THIRD_PARTY:
        if platform in html_lower:
            name = platform.split(".")[0].title()
            return True, name
    return False, None


def identify_own_form_type(html: str) -> str:
    """
    If form is own, identify what it's built with.
    Helps client understand how easy it is to fix.
    """
    html_lower = html.lower()
    for form_type, signals in OWN_FORM_SIGNALS.items():
        if any(signal in html_lower for signal in signals):
            return form_type
    return "Own (Custom HTML)"


def extract_form_html(page) -> str:
    """
    Extract the raw HTML of the first booking-related form on the page.
    Used by Module 4 (CRO analyzer).
    """
    try:
        forms = page.locator("form").all()
        if not forms:
            return ""

        # prefer forms with booking-related input names or ids
        for form in forms:
            form_html = form.inner_html()
            form_lower = form_html.lower()
            if any(kw in form_lower for kw in ["name", "phone", "email", "message", "date"]):
                return form_html[:3000]  # cap at 3000 chars for GPT

        # fallback: return first form found
        return forms[0].inner_html()[:3000]
    except Exception:
        return ""


# ══════════════════════════════════════════════════════════════════════════════
# MAIN DETECTION FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

def detect_form(website_url: str) -> dict:
    """
    Main entry point for Module 3.

    Strategy:
      1. Visit homepage — look for booking button/link
      2. Click booking button — check where it goes (3rd party redirect?)
      3. If no redirect — check page HTML for 3rd party embed
      4. Check common form URL paths (/contact, /appointment, etc.)
      5. Identify form ownership and extract HTML
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        log("Playwright not installed", "ERROR")
        return _no_form_result("Playwright not installed")

    result = {
        "has_form":  False,
        "is_own":    False,
        "platform":  "None found",
        "form_html": "",
        "form_url":  "",
        "verdict":   "No booking form found",
    }

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-setuid-sandbox"]
        )
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 900},
        )
        page = context.new_page()

        # ── STEP 1: Load homepage ─────────────────────────────────────────────
        try:
            page.goto(website_url, timeout=REQUEST_TIMEOUT * 1000,
                      wait_until="domcontentloaded")
            time.sleep(2)
        except Exception as e:
            browser.close()
            return _no_form_result(f"Homepage load failed: {e}")

        homepage_html = page.content()
        homepage_url  = page.url

        # Quick 3rd party check on homepage HTML before clicking anything
        is_3p, platform = is_third_party_html(homepage_html)
        if is_3p:
            browser.close()
            return {
                "has_form":  True,
                "is_own":    False,
                "platform":  platform,
                "form_html": "",
                "form_url":  homepage_url,
                "verdict":   f"SKIP — 3rd party platform embedded: {platform}",
            }

        # ── STEP 2: Find and click a booking button ───────────────────────────
        booking_link_href = None
        for keyword in BOOKING_KEYWORDS:
            try:
                # try link first
                link = page.locator(
                    f'a:has-text("{keyword}")'
                ).first
                if link.count() > 0 and link.is_visible():
                    booking_link_href = link.get_attribute("href") or ""
                    link.click(timeout=5000)
                    time.sleep(2)
                    break

                # try button
                btn = page.locator(
                    f'button:has-text("{keyword}")'
                ).first
                if btn.count() > 0 and btn.is_visible():
                    btn.click(timeout=5000)
                    time.sleep(2)
                    break

            except Exception:
                continue

        # ── STEP 3: Check current URL after click ─────────────────────────────
        current_url  = page.url
        current_html = page.content()

        # did clicking redirect to 3rd party?
        is_3p, platform = is_third_party_url(current_url)
        if is_3p:
            browser.close()
            return {
                "has_form":  True,
                "is_own":    False,
                "platform":  platform,
                "form_html": "",
                "form_url":  current_url,
                "verdict":   f"SKIP — redirects to 3rd party: {platform}",
            }

        # did the page HTML load a 3rd party iframe or script?
        is_3p, platform = is_third_party_html(current_html)
        if is_3p:
            browser.close()
            return {
                "has_form":  True,
                "is_own":    False,
                "platform":  platform,
                "form_html": "",
                "form_url":  current_url,
                "verdict":   f"SKIP — 3rd party embedded on form page: {platform}",
            }

        # ── STEP 4: Check if a real form exists on current page ───────────────
        form_count = page.locator("form").count()
        if form_count > 0:
            form_html    = extract_form_html(page)
            form_type    = identify_own_form_type(current_html)
            browser.close()
            return {
                "has_form":  True,
                "is_own":    True,
                "platform":  form_type,
                "form_html": form_html,
                "form_url":  current_url,
                "verdict":   f"PASS — own form found ({form_type})",
            }

        # ── STEP 5: Try common form URL paths directly ────────────────────────
        base_url = website_url.rstrip("/")
        for path in FORM_PATHS:
            try:
                page.goto(
                    base_url + path,
                    timeout=REQUEST_TIMEOUT * 1000,
                    wait_until="domcontentloaded"
                )
                time.sleep(1)

                path_url  = page.url
                path_html = page.content()

                # check for 3rd party on this path
                is_3p, platform = is_third_party_url(path_url)
                if is_3p:
                    browser.close()
                    return {
                        "has_form":  True,
                        "is_own":    False,
                        "platform":  platform,
                        "form_html": "",
                        "form_url":  path_url,
                        "verdict":   f"SKIP — redirects to 3rd party on {path}: {platform}",
                    }

                is_3p, platform = is_third_party_html(path_html)
                if is_3p:
                    browser.close()
                    return {
                        "has_form":  True,
                        "is_own":    False,
                        "platform":  platform,
                        "form_html": "",
                        "form_url":  path_url,
                        "verdict":   f"SKIP — 3rd party embedded on {path}: {platform}",
                    }

                # own form found on this path?
                if page.locator("form").count() > 0:
                    form_html = extract_form_html(page)
                    form_type = identify_own_form_type(path_html)
                    browser.close()
                    return {
                        "has_form":  True,
                        "is_own":    True,
                        "platform":  form_type,
                        "form_html": form_html,
                        "form_url":  path_url,
                        "verdict":   f"PASS — own form found at {path} ({form_type})",
                    }

            except Exception:
                continue

        # ── Nothing found ─────────────────────────────────────────────────────
        browser.close()
        return _no_form_result("No booking form found after full scan")


# ── Helper ────────────────────────────────────────────────────────────────────

def _no_form_result(reason: str) -> dict:
    return {
        "has_form":  False,
        "is_own":    False,
        "platform":  "None",
        "form_html": "",
        "form_url":  "",
        "verdict":   f"SKIP — {reason}",
    }


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    test_sites = [
        ("WeCare Family Dentistry",    "https://wecarefamdental.com"),
        ("Hildebrand Family Dental",   "https://hildebrandfamilydental.com"),
    ]

    for name, url in test_sites:
        print(f"\n{'='*60}")
        print(f"Testing: {name}")
        print(f"URL:     {url}")
        result = detect_form(url)
        print(f"Has form:  {result['has_form']}")
        print(f"Is own:    {result['is_own']}")
        print(f"Platform:  {result['platform']}")
        print(f"Form URL:  {result['form_url']}")
        print(f"Verdict:   {result['verdict']}")
        if result["form_html"]:
            print(f"Form HTML: {result['form_html'][:100]}...")
