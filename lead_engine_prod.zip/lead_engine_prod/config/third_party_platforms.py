"""
config/third_party_platforms.py
Every domain/keyword that signals a 3rd party booking system.
Add more as you discover them during real runs.
"""

# Dental / medical specific
DENTAL_PLATFORMS = [
    "zocdoc.com",
    "appointnow.com",         # Planet DDS
    "planetdds.com",
    "denticon.com",
    "practicefusion.com",
    "drchrono.com",
    "opendental.com",
    "nexhealth.com",
    "weave.com",
    "patientpop.com",
    "carestack.com",
    "eaglesoft.net",
    "dentrix.com",
    "curve.dental",
    "dovetailhealth.com",
    "luminadental.com",
]

# General booking / scheduling
GENERAL_PLATFORMS = [
    "calendly.com",
    "acuityscheduling.com",
    "squareup.com/appointments",
    "squarespace.com/appointments",
    "setmore.com",
    "booksy.com",
    "vagaro.com",
    "mindbodyonline.com",
    "schedulicity.com",
    "simplybook.me",
    "picktime.com",
    "10to8.com",
    "appointlet.com",
    "oncehub.com",
    "youcanbook.me",
    "hubspot.com/meetings",
    "tidycal.com",
]

# Website builder native booking (still 3rd party infrastructure)
BUILDER_PLATFORMS = [
    "wixbooking",
    "wix.com/bookings",
    "squaresite.com",
    "janeapp.com",
]

# GitHub / external hosting (always 3rd party)
EXTERNAL_HOSTING = [
    "github.io",
    "netlify.app",
    "vercel.app",
    "webflow.io",        # webflow.io = staging, not their own domain
]

# Combine all into one flat list for easy checking
ALL_THIRD_PARTY = (
    DENTAL_PLATFORMS +
    GENERAL_PLATFORMS +
    BUILDER_PLATFORMS +
    EXTERNAL_HOSTING
)
