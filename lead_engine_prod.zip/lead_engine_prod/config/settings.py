"""
config/settings.py
All settings loaded from environment variables / .env file.
NEVER hardcode API keys here — use .env file locally, env vars on Railway/server.
"""

import os
from dotenv import load_dotenv

# Load .env file if it exists (local development)
load_dotenv()

# ── API Keys ──────────────────────────────────────────────────────────────────
APIFY_API_TOKEN       = os.getenv("APIFY_API_TOKEN", "")
HUNTER_API_KEY        = os.getenv("HUNTER_API_KEY", "")
OPENAI_API_KEY        = os.getenv("OPENAI_API_KEY", "")
GOOGLE_API_KEY        = os.getenv("GOOGLE_API_KEY", "")

# ── Scraper ───────────────────────────────────────────────────────────────────
DEFAULT_MAX_RESULTS   = int(os.getenv("DEFAULT_MAX_RESULTS", "200"))
REQUEST_TIMEOUT       = int(os.getenv("REQUEST_TIMEOUT", "10"))
SCROLL_PAUSE          = int(os.getenv("SCROLL_PAUSE", "2"))

# ── AI ────────────────────────────────────────────────────────────────────────
GPT_MODEL             = os.getenv("GPT_MODEL", "gpt-4o-mini")
GPT_MAX_TOKENS        = int(os.getenv("GPT_MAX_TOKENS", "300"))
CRO_ANALYSIS_CHARS    = int(os.getenv("CRO_ANALYSIS_CHARS", "3000"))
HOMEPAGE_TEXT_CHARS   = int(os.getenv("HOMEPAGE_TEXT_CHARS", "2000"))

# ── Hunter.io ─────────────────────────────────────────────────────────────────
HUNTER_MIN_CONFIDENCE = int(os.getenv("HUNTER_MIN_CONFIDENCE", "70"))
HUNTER_RATE_LIMIT     = int(os.getenv("HUNTER_RATE_LIMIT", "15"))

# ── Output ────────────────────────────────────────────────────────────────────
OUTPUT_DIR            = os.getenv("OUTPUT_DIR", "output")
LOG_DIR               = os.getenv("LOG_DIR", "logs")

def validate_keys() -> dict:
    """Returns which API keys are set. Call at startup."""
    return {
        "APIFY_API_TOKEN": bool(APIFY_API_TOKEN),
        "HUNTER_API_KEY":  bool(HUNTER_API_KEY),
        "OPENAI_API_KEY":  bool(OPENAI_API_KEY),
        "GOOGLE_API_KEY":  bool(GOOGLE_API_KEY),
    }
