# Lead Qualification Engine

Automatically finds, qualifies, and delivers pre-vetted local business leads
with owner emails and AI-written cold email openers.

## What It Does

Scrapes Google Maps → visits each website → detects if booking form is own vs
3rd party → analyzes CRO issues → finds owner email → writes a personalized
email opener. All automatically.

**Cost per 100 qualified leads: ~$4. You charge: $150–$300. Margin: 98%+**

---

## Quick Start (Local Computer)

### Step 1 — Prerequisites

- Python 3.11+
- Git

### Step 2 — Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/lead-engine.git
cd lead-engine
pip install -r requirements.txt
playwright install chromium
```

### Step 3 — Set Up API Keys

```bash
cp .env.example .env
```

Open `.env` and add your keys:

```
OPENAI_API_KEY=sk-...           ← REQUIRED (platform.openai.com)
APIFY_API_TOKEN=apify_api_...   ← Recommended (apify.com, $5 free)
HUNTER_API_KEY=...              ← Recommended (hunter.io, 50 free/mo)
GOOGLE_API_KEY=AIza...          ← Optional (PageSpeed scores)
```

### Step 4 — Run

```bash
# Check everything is ready
python main.py --client sample_dental --dry-run

# Run full pipeline (200 businesses, Excel output)
python main.py --client sample_dental

# Run with options
python main.py --client sample_dental --limit 50 --output both

# See all clients
python main.py --list-clients
```

Output saves to `output/sample_dental/leads_YYYY-MM-DD_HH-MM.xlsx`

---

## Adding a New Client

1. Create folder: `clients/YOUR_CLIENT_NAME/`
2. Copy and edit config: `cp clients/sample_dental/config.json clients/YOUR_CLIENT_NAME/config.json`
3. Edit the config:

```json
{
  "client_name": "hvac_chicago",
  "niche": "HVAC company",
  "city": "Chicago IL",
  "gates": [
    {"module": "rating_filter", "min": 3.5, "max": 4.6},
    {"module": "review_count_filter", "min": 5, "max": 300},
    {"module": "independent_check"}
  ],
  "output_columns": ["business_name", "owner_email", "top_cro_issue", "ai_email_opener"],
  "delivery": {"format": "excel", "frequency": "weekly", "leads_per_batch": 100}
}
```

4. Run: `python main.py --client hvac_chicago`

### Available Gate Modules

| Gate | Parameters | What it does |
|------|-----------|--------------|
| `rating_filter` | `min`, `max` | Filter by Google rating |
| `review_count_filter` | `min`, `max` | Filter by review count |
| `independent_check` | none | Skip chains & nonprofits |
| `owner_name_required` | none | Skip if owner not findable |
| `mobile_score_filter` | `max` | Skip sites with good mobile score |
| `site_age_filter` | `min_years` | Skip domains newer than N years |

---

## Deploy on Railway (Cloud)

Railway lets you run the pipeline in the cloud — no laptop needed.

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/lead-engine.git
git push -u origin main
```

### Step 2 — Deploy on Railway

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Select your `lead-engine` repository
3. Click **Variables** tab → Add each key:

```
OPENAI_API_KEY     = sk-...
APIFY_API_TOKEN    = apify_api_...
HUNTER_API_KEY     = ...
GOOGLE_API_KEY     = AIza...   (optional)
```

4. Railway reads `railway.toml` and runs automatically
5. Check **Logs** tab to see the pipeline running

### Step 3 — Download Output

Output files save in Railway's ephemeral storage. To get them:
- Check the Logs tab — lead counts are printed there
- Or add a Google Sheets integration (see below)

### Schedule Automatic Weekly Runs on Railway

In railway.toml, add a cron schedule:

```toml
[deploy]
cronSchedule = "0 9 * * 1"   # Every Monday at 9am UTC
startCommand = "python main.py --client sample_dental --limit 200 --output both"
```

---

## API Keys — Where to Get Them

| Key | Where | Free tier | Cost after |
|-----|-------|-----------|-----------|
| `OPENAI_API_KEY` | platform.openai.com → API Keys | $5 credit | ~$0.002/lead |
| `APIFY_API_TOKEN` | console.apify.com → Integrations | $5 credit | ~$3/200 results |
| `HUNTER_API_KEY` | hunter.io → API | 50 searches/mo | $49/mo for 500 |
| `GOOGLE_API_KEY` | console.cloud.google.com | 25,000/day free | Free tier sufficient |

---

## Cost Per 100 Qualified Leads

| Step | Tool | Cost |
|------|------|------|
| Google Maps (300 raw) | Apify | ~$3.00 |
| Email finding | Hunter.io | ~$0.60 |
| CRO analysis + AI openers | OpenAI | ~$0.40 |
| Website check, WHOIS | Free | $0.00 |
| **Total** | | **~$4.00** |

You charge clients $150–$300 per batch. **Margin: 98%+**

---

## Project Structure

```
lead_engine/
├── main.py                    ← Entry point
├── .env.example               ← Copy to .env and fill in keys
├── requirements.txt
├── railway.toml               ← Railway deployment config
├── Procfile                   ← Heroku/Railway worker config
│
├── config/
│   ├── settings.py            ← Loads all keys from .env
│   └── third_party_platforms.py  ← Known 3rd party booking platforms
│
├── core/
│   ├── pipeline.py            ← Master orchestrator
│   ├── output.py              ← Excel + CSV formatter
│   └── logger.py              ← Console + file logging
│
├── modules/
│   ├── scraper.py             ← Google Maps (Apify + Playwright)
│   ├── website_checker.py     ← CMS, age, mobile score
│   ├── form_detector.py       ← Own vs 3rd party form detection
│   ├── cro_analyzer.py        ← GPT CRO issue analysis
│   ├── gate_engine.py         ← Client custom gates
│   ├── owner_finder.py        ← Owner name extraction
│   ├── email_finder.py        ← 4-method email waterfall
│   └── ai_writer.py           ← AI email opener generator
│
├── clients/
│   └── sample_dental/
│       └── config.json        ← Client ICP + gates
│
├── output/                    ← Generated lead reports (gitignored)
└── logs/                      ← Run logs (gitignored)
```

---

## Troubleshooting

**"No results from scraper"**
→ Add your APIFY_API_TOKEN to .env — Playwright fallback works but is slower

**"OPENAI_API_KEY not set"**
→ This key is required. Add it to .env

**"No qualified leads found"**
→ Try `--limit 300` to scrape more, or loosen gates in config.json

**"playwright: browser not found"**
→ Run: `playwright install chromium`

**Slow on Railway**
→ Reduce `--limit` to 50–100 for first test run

---

## License

MIT — use freely for commercial purposes.
